﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PublicToolsLib.HelpImg
{
    /// <summary>
    /// 图片处理类
    /// </summary>
    public class ImageHandlerHelper
    {

        /// <summary>
        /// 从特定位置生成自定义宽和高的缩略图(宽度和高度比例不对的图片容易变形)
        /// </summary> 
        /// <param name="imgSourcePath">源图路径（物理路径）</param>
        /// <param name="imgCompressPath">缩略图路径（物理路径）</param>
        /// <param name="imgWidth">缩略图指定宽度</param>
        /// <param name="imgHeight">缩略图指定高度</param>
        public static void MakeThumbnail(string imgSourcePath, string imgCompressPath, double imgWidth, double imgHeight)
        {
            Image imgSource = null;
            //新建一个bmp图片
            System.Drawing.Image bitmap = null;
            //新建一个画板
            System.Drawing.Graphics g = null;
            try
            {
                imgSource = System.Drawing.Image.FromFile(imgSourcePath);
                double proportion1;
                double proportion2;
                int x = 0;
                int y = 0;
                int ow = imgSource.Width;//原图的宽
                int oh = imgSource.Height;//原图的高
                proportion1 = imgHeight / Convert.ToDouble(oh);
                proportion2 = imgWidth / Convert.ToDouble(ow);
                if (imgHeight > oh && imgWidth > ow)  //如果宽高都小于要缩放的就不缩以与大小缩略
                {
                    imgHeight = oh;
                    imgWidth = ow;
                }
                else
                {
                    //根据比例设定相应的高宽
                    if (proportion1 > proportion2)
                    {
                        imgHeight = proportion2 * imgSource.Height;
                    }
                    else
                    {
                        imgWidth = proportion1 * imgSource.Width;
                    }
                }

                //新建一个bmp图片
                bitmap = new System.Drawing.Bitmap(Convert.ToInt32(imgWidth), Convert.ToInt32(imgHeight));
                //新建一个画板
                g = System.Drawing.Graphics.FromImage(bitmap);
                //设置高质量插值法
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
                //设置高质量,低速度呈现平滑程度
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                //清空画布并以透明背景色填充
                g.Clear(System.Drawing.Color.Transparent);
                //在指定位置并且按指定大小绘制原图片的指定部分
                g.DrawImage(imgSource, new System.Drawing.Rectangle(0, 0, Convert.ToInt32(imgWidth), Convert.ToInt32(imgHeight)), new System.Drawing.Rectangle(x, y, ow, oh), System.Drawing.GraphicsUnit.Pixel);
                //以jpg格式保存缩略图WebControls
                //File.Delete(thumbnailPath);
                bitmap.Save(imgCompressPath, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            catch (Exception ex)
            {
                //
            }
            finally
            {
                try
                {
                    g.Dispose();
                    bitmap.Dispose();
                    imgSource.Dispose();
                }
                catch (Exception ex2)
                {
                    //
                }
            }
        }

        /// <summary>
        /// 从特定位置生成自定义宽和高的缩略图(裁剪模式)
        /// </summary>
        /// <param name="originalImagePath">源图路径（物理路径）</param>
        /// <param name="thumbnailPath">缩略图路径（物理路径）</param>
        /// <param name="width">缩略图宽度</param>
        /// <param name="height">缩略图高度</param>
        /// <param name="mode">生成缩略图的方式:HW-W-H-Cut</param>    
        public static void MakeThumbnail(string originalImagePath, string thumbnailPath, int width, int height, string mode)
        {
            System.Drawing.Image originalImage = System.Drawing.Image.FromFile(originalImagePath);

            MakeThumbnail(originalImage, thumbnailPath, width, height, mode);
            #region
            /*
            int towidth = width;
            int toheight = height;
            int x = 0;
            int y = 0;
            int ow = originalImage.Width;
            int oh = originalImage.Height;
            switch (mode)
            {
                case "HW"://指定高宽缩放（可能变形）                
                    break;
                case "W"://指定宽，高按比例                    
                    toheight = originalImage.Height * width / originalImage.Width;
                    break;
                case "H"://指定高，宽按比例
                    towidth = originalImage.Width * height / originalImage.Height;
                    break;
                case "Cut"://指定高宽裁减（不变形）                
                    if ((double)originalImage.Width / (double)originalImage.Height > (double)towidth / (double)toheight)
                    {
                        oh = originalImage.Height;
                        ow = originalImage.Height * towidth / toheight;
                        y = 0;
                        x = (originalImage.Width - ow) / 2;
                    }
                    else
                    {
                        ow = originalImage.Width;
                        oh = originalImage.Width * height / towidth;
                        x = 0;
                        y = (originalImage.Height - oh) / 2;
                    }
                    break;
                default:
                    break;
            }
            //新建一个bmp图片
            System.Drawing.Image bitmap = new System.Drawing.Bitmap(towidth, toheight);
            //新建一个画板
            System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(bitmap);
            //设置高质量插值法
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
            //设置高质量,低速度呈现平滑程度
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            //清空画布并以透明背景色填充
            g.Clear(System.Drawing.Color.Transparent);
            //在指定位置并且按指定大小绘制原图片的指定部分
            g.DrawImage(originalImage, new System.Drawing.Rectangle(0, 0, towidth, toheight),
                new System.Drawing.Rectangle(x, y, ow, oh),
                System.Drawing.GraphicsUnit.Pixel);
            try
            {
                //以jpg格式保存缩略图
                bitmap.Save(thumbnailPath, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            catch (System.Exception e)
            {
                throw e;
            }
            finally
            {
                originalImage.Dispose();
                bitmap.Dispose();
                g.Dispose();
            }
             */
            #endregion
        }



        /// <summary>
        /// 从特定位置生成自定义宽和高的缩略图(裁剪模式)
        /// </summary>
        /// <param name="originalImage">原图对象</param>
        /// <param name="thumbnailPath">缩略图路径（物理路径）</param>
        /// <param name="width">缩略图宽度</param>
        /// <param name="height">缩略图高度</param>
        /// <param name="mode">生成缩略图的方式:HW-W-H-Cut</param>    
        public static void MakeThumbnail(System.Drawing.Image originalImage, string thumbnailPath, int width, int height, string mode)
        {
            //System.Drawing.Image originalImage = System.Drawing.Image.FromFile(originalImagePath);

            int towidth = width;
            int toheight = height;
            int x = 0;
            int y = 0;
            int ow = originalImage.Width;
            int oh = originalImage.Height;
            switch (mode)
            {
                case "HW"://指定高宽缩放（可能变形）                
                    break;
                case "W"://指定宽，高按比例                    
                    toheight = originalImage.Height * width / originalImage.Width;
                    break;
                case "H"://指定高，宽按比例
                    towidth = originalImage.Width * height / originalImage.Height;
                    break;
                case "Cut"://指定高宽裁减（不变形）                
                    if ((double)originalImage.Width / (double)originalImage.Height > (double)towidth / (double)toheight)
                    {
                        oh = originalImage.Height;
                        ow = originalImage.Height * towidth / toheight;
                        y = 0;
                        x = (originalImage.Width - ow) / 2;
                    }
                    else
                    {
                        ow = originalImage.Width;
                        oh = originalImage.Width * height / towidth;
                        x = 0;
                        y = (originalImage.Height - oh) / 2;
                    }
                    break;
                default:
                    break;
            }
            //新建一个bmp图片
            System.Drawing.Image bitmap = new System.Drawing.Bitmap(towidth, toheight);
            //新建一个画板
            System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(bitmap);
            //设置高质量插值法
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
            //设置高质量,低速度呈现平滑程度
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            //清空画布并以透明背景色填充
            g.Clear(System.Drawing.Color.Transparent);
            //在指定位置并且按指定大小绘制原图片的指定部分
            g.DrawImage(originalImage, new System.Drawing.Rectangle(0, 0, towidth, toheight),
                new System.Drawing.Rectangle(x, y, ow, oh),
                System.Drawing.GraphicsUnit.Pixel);
            try
            {
                //以jpg格式保存缩略图
                bitmap.Save(thumbnailPath, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            catch (System.Exception e)
            {
                throw e;
            }
            finally
            {
                originalImage.Dispose();
                bitmap.Dispose();
                g.Dispose();
            }
        }


        /// <summary>
        /// 从原点0,0开始生成自定义宽和高的缩略图
        /// </summary>
        /// <param name="originalImagePath">原图对象</param>
        /// <param name="thumbnailPath">缩略图路径（物理路径）</param>
        /// <param name="width">缩略图宽度</param>
        /// <param name="height">缩略图高度</param>
        /// <param name="mode">生成缩略图的方式:HW-W-H-Cut</param>    
        public static void PointThumbnail(string originalImagePath, string thumbnailPath, int width, int height, string mode = "Cut")
        {
            System.Drawing.Image originalImage = System.Drawing.Image.FromFile(originalImagePath);
            PointThumbnail(originalImage, thumbnailPath, width, height, mode);
        }

        /// <summary>
        /// 从原点0,0开始生成自定义宽和高的缩略图
        /// </summary>
        /// <param name="originalImage">原图对象</param>
        /// <param name="thumbnailPath">缩略图路径（物理路径）</param>
        /// <param name="width">缩略图宽度</param>
        /// <param name="height">缩略图高度</param>
        /// <param name="mode">生成缩略图的方式:HW-W-H-Cut</param>    
        public static void PointThumbnail(System.Drawing.Image originalImage, string thumbnailPath, int width, int height, string mode)
        {
            int towidth = width;
            int toheight = height;
            int x = 0;
            int y = 0;
            int ow = originalImage.Width;
            int oh = originalImage.Height;
            switch (mode)
            {
                case "HW"://指定高宽缩放（可能变形）                
                    break;
                case "W"://指定宽，高按比例                    
                    toheight = originalImage.Height * width / originalImage.Width;
                    break;
                case "H"://指定高，宽按比例
                    towidth = originalImage.Width * height / originalImage.Height;
                    break;
                case "Cut"://指定高宽裁减（不变形）                
                    if ((double)originalImage.Width / (double)originalImage.Height > (double)towidth / (double)toheight)
                    {
                        oh = originalImage.Height;
                        ow = originalImage.Height * towidth / toheight;
                        //y = 0;
                        //x = (originalImage.Width - ow) / 2;
                    }
                    else
                    {
                        ow = originalImage.Width;
                        oh = originalImage.Width * height / towidth;
                        //x = 0;
                        //y = (originalImage.Height - oh) / 2;
                    }
                    break;
                default:
                    break;
            }
            //新建一个bmp图片
            System.Drawing.Image bitmap = new System.Drawing.Bitmap(towidth, toheight);
            //新建一个画板
            System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(bitmap);
            //设置高质量插值法
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
            //设置高质量,低速度呈现平滑程度
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            //清空画布并以透明背景色填充
            g.Clear(System.Drawing.Color.Transparent);
            //在指定位置并且按指定大小绘制原图片的指定部分
            g.DrawImage(originalImage, new System.Drawing.Rectangle(0, 0, towidth, toheight),
                new System.Drawing.Rectangle(x, y, ow, oh),
                System.Drawing.GraphicsUnit.Pixel);
            try
            {
                //以jpg格式保存缩略图
                bitmap.Save(thumbnailPath, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            catch (System.Exception e)
            {
                throw e;
            }
            finally
            {
                originalImage.Dispose();
                bitmap.Dispose();
                g.Dispose();
            }
        }


        /// <summary>
        /// 图片的旋转(针对手机拍照上传会后角度会被乱旋转)
        /// System.Drawing.Image img = System.Drawing.Image.FromFile(_newImgUrl);_newImgUrl--文件物理路径
        /// RotateImage(img);
        /// MakeThumbnail(img, context.Server.MapPath("~/thumb/" + _strNewFileName), 360, 290, "Cut");--将该图片生成缩略图
        /// </summary>
        /// <param name="img">原图对象</param>
        public static void RotateImage(System.Drawing.Image img)
        {
            System.Drawing.Imaging.PropertyItem[] exif = img.PropertyItems;
            byte orientation = 0;
            foreach (System.Drawing.Imaging.PropertyItem i in exif)
            {
                if (i.Id == 274)
                {
                    orientation = i.Value[0];
                    i.Value[0] = 1;
                    img.SetPropertyItem(i);
                }
            }

            switch (orientation)
            {
                case 2:
                    img.RotateFlip(System.Drawing.RotateFlipType.RotateNoneFlipX);
                    break;
                case 3:
                    img.RotateFlip(System.Drawing.RotateFlipType.Rotate180FlipNone);
                    break;
                case 4:
                    img.RotateFlip(System.Drawing.RotateFlipType.RotateNoneFlipY);
                    break;
                case 5:
                    img.RotateFlip(System.Drawing.RotateFlipType.Rotate90FlipX);
                    break;
                case 6:
                    img.RotateFlip(System.Drawing.RotateFlipType.Rotate90FlipNone);
                    break;
                case 7:
                    img.RotateFlip(System.Drawing.RotateFlipType.Rotate270FlipX);
                    break;
                case 8:
                    img.RotateFlip(System.Drawing.RotateFlipType.Rotate270FlipNone);
                    break;
                default:
                    break;
            }
            foreach (System.Drawing.Imaging.PropertyItem i in exif)
            {
                if (i.Id == 40962)
                {
                    i.Value = BitConverter.GetBytes(img.Width);
                }
                else if (i.Id == 40963)
                {
                    i.Value = BitConverter.GetBytes(img.Height);
                }
            }
        }
    }

}
