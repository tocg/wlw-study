﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicToolsLib.HelpImg
{
    /// <summary>
    /// 图片水印
    /// </summary>
    public class ImageWaterMarkHelper
    {
        #region param
        private string strCopyright, strMarkPath, strPhotoPath, strSavePath;
        private int iMarkRightSpace, iMarkButtomSpace, iDiaphaneity;
        private int iFontRightSpace = 0, iFontButtomSpace = 0, iFontDiaphaneity = 80;
        private int iFontSize = 10;
        private bool bShowCopyright = true, bShowMarkImage = true;
        #endregion

        public ImageWaterMarkHelper()
        {
            this.strCopyright = "";
            this.strMarkPath = null;
            this.strPhotoPath = null;
            this.strSavePath = null;
            this.iDiaphaneity = 70;
            this.iMarkRightSpace = 0;
            this.iMarkButtomSpace = 0;
        }

        /// <summary>
        /// 主要用两样都加的
        /// </summary>
        /// <param name="copyright">要加入的文字</param>
        /// <param name="markPath">水印图片路径</param>
        /// <param name="photoPath">要加水印的图片路径</param>
        /// <param name="savePath">处理后的图片路径</param>
        public ImageWaterMarkHelper(string copyright, string markPath, string photoPath, string savePath)
        {
            this.strCopyright = copyright;
            this.strMarkPath = markPath;
            this.strPhotoPath = photoPath;
            this.strSavePath = savePath;
            this.iDiaphaneity = 70;
            this.iMarkRightSpace = 0;
            this.iMarkButtomSpace = 0;
        }

        #region
        /// <summary>
        /// 设置是否显示水印文字
        /// </summary>
        public bool ShowCopyright
        {
            set { this.bShowCopyright = value; }
        }

        /// <summary>
        /// 设置是否显示水印图片
        /// </summary>
        public bool ShowMarkImage
        {
            set { this.bShowMarkImage = value; }
        }
        /// <summary>
        /// 获取或设置要加入的文字
        /// </summary>
        public string Copyright
        {
            set { this.strCopyright = value; }
        }

        /// <summary>
        /// 获取或设置加水印后的图片路径
        /// </summary>
        public string SavePath
        {
            get { return this.strSavePath; }
            set { this.strSavePath = value; }
        }

        /// <summary>
        /// 获取或设置水印图片路径
        /// </summary>
        public string MarkPath
        {
            get { return this.strMarkPath; }
            set { this.strMarkPath = value; }
        }

        /// <summary>
        /// 获取或设置要加水印图片的路径
        /// </summary>
        public string PhotoPath
        {
            get { return this.strPhotoPath; }
            set { this.strPhotoPath = value; }
        }

        /// <summary>
        /// 设置水印图片的透明度
        /// </summary>
        public int Diaphaneity
        {
            set
            {
                if (value > 0 && value <= 100)
                    this.iDiaphaneity = value;
            }
        }

        /// <summary>
        /// 设置水印字体的透明度0-255
        /// </summary>
        public int FontDiaphaneity
        {
            set
            {
                if (value >= 0 && value <= 255)
                    this.iFontDiaphaneity = value;
            }
        }

        /// <summary>
        /// 设置水印图片在修改图片中距左边的高度
        /// </summary>
        public int MarkRightSpace
        {
            set { this.iMarkRightSpace = value; }
        }

        /// <summary>
        /// 设置水印图片在修改图片中距底部的高度
        /// </summary>
        public int MarkButtomSpace
        {
            set { this.iMarkButtomSpace = value; }
        }

        /// <summary>
        /// 设置水印字体在修改图片中距左边的距离
        /// </summary>
        public int FontRightSpace
        {
            set { iFontRightSpace = value; }
        }

        /// <summary>
        /// 设置水印字体在修改图片中距底部的高度
        /// </summary>
        public int FontButtomSpace
        {
            set { iFontButtomSpace = value; }
        }

        #endregion


        /// <summary>
        /// 生成水印图片
        /// </summary>
        /// <returns></returns>
        public void CreateMarkPhoto()
        {
            Bitmap bmImageWater = null;
            Image gPhoto = Image.FromFile(this.strPhotoPath);
            int PhotoWidth = gPhoto.Width;
            int PhotoHeight = gPhoto.Height;
            Bitmap bitPhoto = new Bitmap(PhotoWidth, PhotoHeight, PixelFormat.Format24bppRgb);
            bitPhoto.SetResolution(gPhoto.HorizontalResolution, gPhoto.VerticalResolution);

            try
            {
                if (bShowCopyright)
                {
                    Graphics grPhoto = Graphics.FromImage(bitPhoto);
                    grPhoto.SmoothingMode = SmoothingMode.AntiAlias;
                    grPhoto.DrawImage(gPhoto, new Rectangle(0, 0, PhotoWidth, PhotoHeight), 0, 0, PhotoWidth, PhotoHeight, GraphicsUnit.Pixel);

                    Font crFont = new Font("楷体", iFontSize, FontStyle.Bold);
                    SizeF crSize = grPhoto.MeasureString(strCopyright, crFont);

                    //设置字体在图片中的位置
                    float yPosFromBottom = PhotoHeight - iFontButtomSpace - (crSize.Height);

                    //float xCenterOfImg = (phWidth/2);
                    float xCenterOfImg = PhotoWidth - iFontRightSpace - (crSize.Width / 2);
                    //设置字体居中

                    StringFormat StrFormat = new StringFormat();
                    StrFormat.Alignment = StringAlignment.Center;

                    //设置绘制文本的颜色和纹理 (Alpha=153)
                    SolidBrush semiTransBrush2 = new SolidBrush(Color.FromArgb(this.iFontDiaphaneity, 0, 0, 0));

                    //将版权信息绘制到图象上
                    grPhoto.DrawString(strCopyright, crFont, semiTransBrush2, new PointF(xCenterOfImg, yPosFromBottom), StrFormat);

                    gPhoto = bitPhoto;
                    grPhoto.Dispose();
                }



                if (bShowMarkImage)
                {
                    //创建一个需要填充水银的Image对象
                    Image imgImageWater = new Bitmap(strMarkPath);
                    int iMarkWidth = imgImageWater.Width;
                    int iMarkmHeight = imgImageWater.Height;

                    Graphics grImageWater = null;
                    if (bShowCopyright)
                    {
                        //在原来修改过的bmPhoto上创建一个水银位图
                        bmImageWater = new Bitmap(bitPhoto);
                        bmImageWater.SetResolution(gPhoto.HorizontalResolution, gPhoto.VerticalResolution);
                    }
                    else
                    {
                        bmImageWater = new Bitmap(gPhoto);
                    }

                    //将位图bmImageWater加载到Graphics对象
                    grImageWater = Graphics.FromImage(bmImageWater);
                    ImageAttributes imageAttributes = new ImageAttributes();

                    ColorMap colorMap = new ColorMap();

                    colorMap.OldColor = Color.FromArgb(255, 0, 255, 0);
                    colorMap.NewColor = Color.FromArgb(0, 0, 0, 0);

                    ColorMap[] remapTable = { colorMap };

                    imageAttributes.SetRemapTable(remapTable, ColorAdjustType.Bitmap);

                    float[][] colorMatrixElements = {
                          new float[] {1.0f, 0.0f, 0.0f, 0.0f, 0.0f},
                          new float[] {0.0f, 1.0f, 0.0f, 0.0f, 0.0f},
                          new float[] {0.0f, 0.0f, 1.0f, 0.0f, 0.0f},
                          new float[] {0.0f, 0.0f, 0.0f, (float)iDiaphaneity/100f, 0.0f},
                          new float[] {0.0f, 0.0f, 0.0f, 0.0f, 1.0f}};
                    ColorMatrix wmColorMatrix = new ColorMatrix(colorMatrixElements);

                    imageAttributes.SetColorMatrix(wmColorMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);

                    grImageWater.DrawImage(imgImageWater, new Rectangle((PhotoWidth - iMarkRightSpace - (iMarkWidth / 2)), (PhotoHeight - iMarkButtomSpace - (iMarkmHeight / 2)), iMarkWidth, iMarkmHeight), 0, 0, iMarkWidth, iMarkmHeight, GraphicsUnit.Pixel, imageAttributes);

                    gPhoto = bmImageWater;
                    grImageWater.Dispose();
                    imgImageWater.Dispose();
                }
                gPhoto.Save(strSavePath, ImageFormat.Jpeg);
            }
            finally
            {

                if (bitPhoto != null)
                    bitPhoto.Dispose();

                if (bmImageWater != null)
                    bmImageWater.Dispose();

                gPhoto.Dispose();
            }

        }
    }
}
